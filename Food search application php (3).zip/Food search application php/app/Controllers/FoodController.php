<?php

namespace App\Controllers;

use App\Services\FoodService;
use App\Requests\FilterRequest;
use Illuminate\Http\Request;

class FoodController extends Controller
{
    protected $foodService;

    public function __construct(FoodService $foodService)
    {
        $this->foodService = $foodService;
    }

    public function filter(FilterRequest $request)
    {
        $filters = $request->validated();
        return response()->json($this->foodService->filter($filters));
    }
}
