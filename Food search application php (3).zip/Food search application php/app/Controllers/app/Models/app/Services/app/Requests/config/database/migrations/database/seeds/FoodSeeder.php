<?php

use Illuminate\Database\Seeder;
use App\Models\Food;

class FoodSeeder extends Seeder
{
    public function run()
    {
        Food::create([
            'name' => 'Margherita Pizza',
            'description' => 'Classic pizza with mozzarella cheese',
            'price' => 9.99,
            'average_rating' => 4.5,
            'category' => 'pizza',
            'customization' => json_encode([
                'toppings' => ['cheddar', 'mozzarella']
            ]),
            'type' => 'veg'
        ]);

        // Add more seeds as needed
    }
}
