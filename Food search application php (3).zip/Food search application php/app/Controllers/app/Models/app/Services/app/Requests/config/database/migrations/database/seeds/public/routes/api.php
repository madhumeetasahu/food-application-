<?php

use Illuminate\Support\Facades\Route;
use App\Controllers\FoodController;

Route::get('/foods', [FoodController::class, 'filter']);
