# Food Search Application

## Requirements
- PHP 7.3 or higher
- Composer
- MySQL

## Installation
1. Clone the repository.
2. Run `composer install` to install dependencies.
3. Copy `.env.example` to `.env` and configure your environment variables.
4. Run `php artisan migrate --seed` to set up the database.
5. Run `php artisan serve` to start the application.

## API Documentation
The API documentation is available at `/swagger/swagger.yaml`.

## Running Tests
Run `phpunit` to execute the tests.
