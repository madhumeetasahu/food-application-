<?php

namespace App\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FilterRequest extends FormRequest
{
    public function rules()
    {
        return [
            'price_range' => 'array|min:2|max:2',
            'price_range.*' => 'numeric',
            'average_rating' => 'numeric|min:0|max:5',
            'category' => 'string',
            'toppings' => 'string',
            'type' => 'string|in:veg,non-veg,both',
        ];
    }

    public function authorize()
    {
        return true;
    }
}
