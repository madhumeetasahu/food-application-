<?php

namespace App\Services;

use App\Models\Food;

class FoodService
{
    public function filter(array $filters)
    {
        $query = Food::query();

        if (isset($filters['price_range'])) {
            $query->whereBetween('price', $filters['price_range']);
        }

        if (isset($filters['average_rating'])) {
            $query->where('average_rating', '>=', $filters['average_rating']);
        }

        if (isset($filters['category'])) {
            $query->whereIn('category', explode(',', $filters['category']));
        }

        if (isset($filters['toppings'])) {
            $query->whereHas('customization', function ($q) use ($filters) {
                $q->whereIn('toppings', explode(',', $filters['toppings']));
            });
        }

        if (isset($filters['type'])) {
            $query->where('type', $filters['type']);
        }

        return $query->paginate(10);
    }
}
