<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Services\FoodService;

class FoodServiceTest extends TestCase
{
    public function testFilterService()
    {
        // Add test cases for the filter service
    }
}
